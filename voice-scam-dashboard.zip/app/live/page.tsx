"use client"

import { useState, useMemo } from "react"
import useSWR from "swr"
import { MicButton } from "@/components/mic-button"
import { Waveform } from "@/components/waveform"
import { ProgressRing } from "@/components/progress-ring"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardShell } from "@/components/shell/dashboard-shell"
import { cn } from "@/lib/utils"

const fetcher = (url: string, payload?: any) =>
  fetch(url, {
    method: "POST",
    body: JSON.stringify(payload ?? {}),
  }).then((r) => r.json())

const KEYWORDS = ["otp", "transfer now", "urgent", "gift card", "bank details", "one time password", "pin"]

function highlight(text: string, keywords: string[]) {
  if (!text) return null
  const parts = text.split(
    new RegExp(`(${keywords.map((k) => k.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")).join("|")})`, "gi"),
  )
  return parts.map((part, i) =>
    keywords.some((k) => k.toLowerCase() === part.toLowerCase()) ? (
      <span key={i} className="font-medium text-[color:var(--accent)]">
        {part}
      </span>
    ) : (
      <span key={i}>{part}</span>
    ),
  )
}

export default function LivePage() {
  const [listening, setListening] = useState(false)

  const { data } = useSWR(
    listening ? ["/api/analyze", { mode: "live" }] : null,
    ([url, payload]) => fetcher(url, payload),
    { refreshInterval: 1200 },
  )

  const status = data?.status ?? (listening ? "Listening" : "Idle")
  const probability = Math.round(data?.probability ?? 0)
  const triggered = probability >= 75

  const statusColor = useMemo(
    () =>
      triggered
        ? "text-[color:var(--accent)]"
        : probability >= 40
          ? "text-[color:var(--chart-1)]"
          : "text-muted-foreground",
    [triggered, probability],
  )

  return (
    <DashboardShell>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 border-border/60 bg-secondary/60 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-balance">Live Call Monitor</CardTitle>
            <Badge variant="outline" className={cn("text-xs", statusColor)}>
              {status}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center gap-6">
              <MicButton active={listening} onToggle={() => setListening((v) => !v)} />
              <Waveform active={listening} />
              <div className="text-sm text-muted-foreground">
                {listening ? "Listening and analyzing..." : "Tap the mic to start."}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <div className="rounded-xl border border-border/60 bg-card/90 p-4 backdrop-blur">
                <div className="mb-2 text-sm font-medium">Transcribed Speech</div>
                <div className="h-40 overflow-y-auto rounded-md border border-border/50 bg-secondary/60 p-3 leading-relaxed">
                  {data?.transcript ? (
                    <p className="text-pretty">{highlight(data.transcript, data.keywords ?? KEYWORDS)}</p>
                  ) : (
                    <p className="text-muted-foreground">Waiting for audio...</p>
                  )}
                </div>
                <div className="mt-2 text-xs text-muted-foreground">Highlighted keywords flagged as high risk.</div>
              </div>

              <div className="flex items-center justify-center">
                <ProgressRing value={probability} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-secondary/60 backdrop-blur">
          <CardHeader>
            <CardTitle>Detection Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span>Mode</span>
              <span className="text-muted-foreground">{listening ? "Real-time" : "Idle"}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Scam Probability</span>
              <span className={statusColor}>{probability}%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Matched Keywords</span>
              <span className="text-muted-foreground">{(data?.keywords ?? []).join(", ") || "—"}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={triggered}>
        <AlertDialogContent className="backdrop-blur">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[color:var(--accent)]">Scam Risk Detected</AlertDialogTitle>
            <AlertDialogDescription>
              High probability of scam activity detected. Consider ending the call or verifying identity.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Dismiss</AlertDialogCancel>
            <AlertDialogAction className="bg-[color:var(--accent)] text-[color:var(--accent-foreground)] hover:opacity-90">
              Mark Reviewed
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardShell>
  )
}
