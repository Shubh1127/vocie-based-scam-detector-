import { NextResponse } from "next/server"

const samples = [
  "Hello, this is your bank. We detected unusual activity. Please share your OTP to verify.",
  "Hi! Could you transfer now? It is urgent to avoid account suspension.",
  "Your parcel requires an additional fee. Pay via gift card immediately to release.",
  "Friendly reminder: your appointment is tomorrow at 3 PM. Call back to reschedule.",
  "We noticed login attempts. Do not share your one time password with anyone.",
]

const KEYWORDS = ["otp", "transfer now", "urgent", "gift card", "bank", "one time password", "pin"]

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}) as any)
  const mode = body?.mode ?? "batch"

  const transcript = samples[Math.floor(Math.random() * samples.length)]
  const found = KEYWORDS.filter((k) => transcript.toLowerCase().includes(k))
  const base = found.length ? 50 + found.length * 10 : Math.random() * 35
  const probability = Math.min(98, Math.max(2, Math.round(base + Math.random() * 20)))

  const status =
    probability >= 75 ? "Scam Detected!" : probability >= 40 ? "Analyzing" : mode === "live" ? "Listening" : "Analyzing"

  return NextResponse.json({
    status,
    transcript,
    keywords: found,
    probability,
  })
}
